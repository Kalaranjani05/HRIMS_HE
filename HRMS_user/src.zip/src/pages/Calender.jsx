import Header from "../components/common/Header"

const Calender = () => {
  return (
    <div className='flex-1 overflow-auto relative z-10'>
      <Header title ='Calender' />
    </div>
  )
}

export default Calender
